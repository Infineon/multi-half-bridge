var searchData=
[
  ['settings_20macros',['Settings Macros',['../group__group__capsense__macros__settings.html',1,'']]]
];
