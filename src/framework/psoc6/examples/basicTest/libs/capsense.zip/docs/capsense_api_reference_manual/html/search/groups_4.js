var searchData=
[
  ['high_2dlevel_20functions',['High-level Functions',['../group__group__capsense__high__level.html',1,'']]]
];
