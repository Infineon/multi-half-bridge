var group__group__capsense__macros__pin =
[
    [ "CY_CAPSENSE_GROUND", "group__group__capsense__macros__pin.html#gad966154287c77eb6cc738db7f4d1da08", null ],
    [ "CY_CAPSENSE_HIGHZ", "group__group__capsense__macros__pin.html#gaead707fb888468852d35412af119f66e", null ],
    [ "CY_CAPSENSE_SHIELD", "group__group__capsense__macros__pin.html#ga704cf1446755dd90a8d31bba205b24a6", null ],
    [ "CY_CAPSENSE_SENSOR", "group__group__capsense__macros__pin.html#ga2ce24899858a4620467617d1e359f20e", null ],
    [ "CY_CAPSENSE_TX_PIN", "group__group__capsense__macros__pin.html#ga18014a9f7faa11af20e25ecb1d0398ae", null ],
    [ "CY_CAPSENSE_RX_PIN", "group__group__capsense__macros__pin.html#ga88e0c991fdb3149ab458780f2ca640e8", null ],
    [ "CY_CAPSENSE_SNS_DISCONNECTED", "group__group__capsense__macros__pin.html#gaca5ba34915743447053b5cd138db74de", null ],
    [ "CY_CAPSENSE_SNS_CONNECTED", "group__group__capsense__macros__pin.html#ga2a7574920a5983ab0fb93e68284200f0", null ]
];