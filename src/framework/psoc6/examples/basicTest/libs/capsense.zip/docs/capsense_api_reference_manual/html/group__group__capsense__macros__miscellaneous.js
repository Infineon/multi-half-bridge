var group__group__capsense__macros__miscellaneous =
[
    [ "CY_CAPSENSE_TU_CMD_COMPLETE_BIT", "group__group__capsense__macros__miscellaneous.html#ga28d833476c3b7b4c16772b4271f50ff4", null ],
    [ "CY_CAPSENSE_STATUS_RESTART_NONE", "group__group__capsense__macros__miscellaneous.html#ga14217247882e150c2ac54b09ad64e4d9", null ],
    [ "CY_CAPSENSE_STATUS_RESTART_DONE", "group__group__capsense__macros__miscellaneous.html#ga58ba0a06e4c9655932c533924e6e7a1c", null ],
    [ "CY_CAPSENSE_IDAC_GAIN_NUMBER", "group__group__capsense__macros__miscellaneous.html#gabf3b4c535607496679a9ba710bcf91ff", null ],
    [ "CY_CAPSENSE_PERCENTAGE_100", "group__group__capsense__macros__miscellaneous.html#ga413e16caaf9cf67a365931831f50dc81", null ],
    [ "CY_CAPSENSE_SCAN_SCOPE_UND", "group__group__capsense__macros__miscellaneous.html#gaa3801c6cd46a47207de6f273dbb5ab78", null ],
    [ "CY_CAPSENSE_SCAN_SCOPE_SGL_SNS", "group__group__capsense__macros__miscellaneous.html#gaf724f5e46b2dcf9342196ed07fefd41e", null ],
    [ "CY_CAPSENSE_SCAN_SCOPE_ALL_SNS", "group__group__capsense__macros__miscellaneous.html#ga8dfc7eb221d7b9ff81afd17b7109861f", null ],
    [ "CY_CAPSENSE_SCAN_SCOPE_SGL_WD", "group__group__capsense__macros__miscellaneous.html#ga17a6ce7b5c3b4883cc1e27f1782853e3", null ],
    [ "CY_CAPSENSE_SCAN_SCOPE_ALL_WD", "group__group__capsense__macros__miscellaneous.html#ga2ce69ee77474719b551552cc84def3c7", null ]
];