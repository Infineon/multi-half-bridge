var searchData=
[
  ['z',['z',['../structcy__stc__capsense__position__t.html#a9a62c41da414fc72932fd1bcd8fbfc96',1,'cy_stc_capsense_position_t']]],
  ['zoomdebounce',['zoomDebounce',['../structcy__stc__capsense__gesture__config__t.html#a13a289ac07a253455c04f3b124e9a7db',1,'cy_stc_capsense_gesture_config_t']]],
  ['zoomdistancemin',['zoomDistanceMin',['../structcy__stc__capsense__gesture__config__t.html#ac80c3e733cdc3999e48f02b94c629f05',1,'cy_stc_capsense_gesture_config_t']]]
];
