var group__group__capsense__macros__process =
[
    [ "CY_CAPSENSE_PROCESS_FILTER", "group__group__capsense__macros__process.html#gaa3b890d5a6646b1c990093614f904b7c", null ],
    [ "CY_CAPSENSE_PROCESS_BASELINE", "group__group__capsense__macros__process.html#ga459185fc700d0afc4556d995730f6052", null ],
    [ "CY_CAPSENSE_PROCESS_DIFFCOUNTS", "group__group__capsense__macros__process.html#ga69cbf309ed5306c0845fbef6d31ba3e8", null ],
    [ "CY_CAPSENSE_PROCESS_CALC_NOISE", "group__group__capsense__macros__process.html#gaaab6d36224e09594d6eb784584e56a63", null ],
    [ "CY_CAPSENSE_PROCESS_THRESHOLDS", "group__group__capsense__macros__process.html#gab3ad76b311ce75be0bb1a66cdadc3b27", null ],
    [ "CY_CAPSENSE_PROCESS_STATUS", "group__group__capsense__macros__process.html#ga1575721ebbdd600b13f843e068dbf282", null ],
    [ "CY_CAPSENSE_PROCESS_ALL", "group__group__capsense__macros__process.html#gaa84b286a4e106b5eeed0141339f7ab6b", null ]
];