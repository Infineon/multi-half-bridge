var searchData=
[
  ['x',['x',['../structcy__stc__capsense__gesture__position__t.html#aa7c7a9666ddec68e4ace38a030ecfdab',1,'cy_stc_capsense_gesture_position_t::x()'],['../structcy__stc__capsense__position__t.html#aaa333fb1aa5285e28ffdf6cc47248741',1,'cy_stc_capsense_position_t::x()'],['../structcy__stc__capsense__ballistic__context__t.html#ae07addb7a565119d5b2244a5bd64dde6',1,'cy_stc_capsense_ballistic_context_t::x()']]],
  ['xdelta',['xDelta',['../structcy__stc__capsense__widget__context__t.html#a723b1a11630c801ad30546fd35cec715',1,'cy_stc_capsense_widget_context_t']]],
  ['xresolution',['xResolution',['../structcy__stc__capsense__widget__config__t.html#adfae2ef0d4316555d1e3c54e39c4aeb5',1,'cy_stc_capsense_widget_config_t']]]
];
