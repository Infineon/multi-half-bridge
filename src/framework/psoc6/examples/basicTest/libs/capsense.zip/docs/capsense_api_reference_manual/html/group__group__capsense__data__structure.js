var group__group__capsense__data__structure =
[
    [ "CapSense Structures", "group__group__capsense__structures.html", "group__group__capsense__structures" ],
    [ "Gesture Structures", "group__group__capsense__gesture__structures.html", "group__group__capsense__gesture__structures" ]
];