var searchData=
[
  ['low_2dlevel_20functions',['Low-level Functions',['../group__group__capsense__low__level.html',1,'']]]
];
