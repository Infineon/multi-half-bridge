var group__group__abstraction__rtos__queue =
[
    [ "CY_RTOS_QUEUE_FULL", "group__group__abstraction__rtos__queue.html#ga08fd892212aaa5c16099259f7eacccfe", null ],
    [ "CY_RTOS_QUEUE_EMPTY", "group__group__abstraction__rtos__queue.html#ga51d3ccf05a8e3c89a6075129074d1c60", null ],
    [ "cy_rtos_init_queue", "group__group__abstraction__rtos__queue.html#gae1980771da597700777263c76c962808", null ],
    [ "cy_rtos_put_queue", "group__group__abstraction__rtos__queue.html#ga59c434edd4d09edc920e261da175cffc", null ],
    [ "cy_rtos_get_queue", "group__group__abstraction__rtos__queue.html#ga5665babb20d6142e90e1133f70936b80", null ],
    [ "cy_rtos_count_queue", "group__group__abstraction__rtos__queue.html#gae5d590529ebef4941be60519655fadc0", null ],
    [ "cy_rtos_space_queue", "group__group__abstraction__rtos__queue.html#gac77316748cd35ac3566e4123c6d34d00", null ],
    [ "cy_rtos_reset_queue", "group__group__abstraction__rtos__queue.html#ga4a2568d71b2f2b215869c8015961b287", null ],
    [ "cy_rtos_deinit_queue", "group__group__abstraction__rtos__queue.html#ga29be5999545930025bbd80d79723f998", null ]
];