var group__group__abstraction__rtos__mutex =
[
    [ "cy_rtos_init_mutex", "group__group__abstraction__rtos__mutex.html#ga79fbca5c574d2bc617af90d4bff6c902", null ],
    [ "cy_rtos_init_mutex2", "group__group__abstraction__rtos__mutex.html#ga0c9c20028f40d04bd4cafdddb2d2e4ca", null ],
    [ "cy_rtos_get_mutex", "group__group__abstraction__rtos__mutex.html#gaad8f978c0a31817f870f193ec72eb5b2", null ],
    [ "cy_rtos_set_mutex", "group__group__abstraction__rtos__mutex.html#ga7b6a9f5fc3910436675c00130399e06d", null ],
    [ "cy_rtos_deinit_mutex", "group__group__abstraction__rtos__mutex.html#ga8cd21b8a116a54ac397209054f35ee45", null ]
];