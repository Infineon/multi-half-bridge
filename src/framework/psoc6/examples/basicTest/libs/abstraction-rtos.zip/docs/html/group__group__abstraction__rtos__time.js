var group__group__abstraction__rtos__time =
[
    [ "cy_rtos_get_time", "group__group__abstraction__rtos__time.html#gabd06aeecc3dfc78f92345c24d381733f", null ],
    [ "cy_rtos_delay_milliseconds", "group__group__abstraction__rtos__time.html#gaa33d9f3026f722ac92950c6215e4283a", null ]
];