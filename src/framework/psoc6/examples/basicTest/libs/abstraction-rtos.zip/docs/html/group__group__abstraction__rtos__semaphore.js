var group__group__abstraction__rtos__semaphore =
[
    [ "cy_rtos_init_semaphore", "group__group__abstraction__rtos__semaphore.html#ga93fbdafe5929ba0703df7d65e2765bfe", null ],
    [ "cy_rtos_get_semaphore", "group__group__abstraction__rtos__semaphore.html#ga4070def066b136082e73547d4e0c3771", null ],
    [ "cy_rtos_set_semaphore", "group__group__abstraction__rtos__semaphore.html#gad53319297963096109f708d5f61bac91", null ],
    [ "cy_rtos_get_count_semaphore", "group__group__abstraction__rtos__semaphore.html#gadc7e84ac4f389499441a792b17147164", null ],
    [ "cy_rtos_deinit_semaphore", "group__group__abstraction__rtos__semaphore.html#ga71c073294cd60ae1c6e97a1f3407ae07", null ]
];